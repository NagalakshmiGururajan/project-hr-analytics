#1.All data about the movies
select * from movies;
#2.All data about directors
select * from directors;
#3.Check how many movies present in IMDB
select count(*) as total_movies from movies;
# 4.Find these 3 directors: James Cameron ; Luc Besson ; John Woo
select * from directors where name in('James Cameron','Luc Besson','John Woo');
#5.All directors name starting with S
select * from directors where name like 'S%';
#6.count of all female directors
select count(*) as female_directors from directors where gender=1;
#7.The name of the 10th first women directors
select name from directors where gender=1 order by name limit 1 offset 9;
#8.Three popular movies
select * from movies order by popularity desc limit 3;
#9.Three bankable movies(bankable =highest revenue)
select title,revenue from movies order by revenue desc limit 3;
#10.The most awarded average vote since the January 1st, 2000.
select Title,Vote_Average from movies where Release_Date >='2000-01-01'
order by Vote_average desc limit 1;
#11.Movie directed by Brenda Chapman
select m.original_title from movies m join directors d 
on m.director_id=d.id
where d.name='Brenda Chapman';
#This query returns no value no movie directed by Brenda Chapman.
#12.Director made the most movies
select d.name,count(*) as total_movies from movies m join directors d on 
m.director_id=d.id group by d.name order by total_movies desc limit 1;
#13.Which director is the most bankable.
select d.name,sum(m.revenue) as total_revenue from movies m join directors d on m.director_id=d.id
group by d.name order by total_revenue desc limit 1;












